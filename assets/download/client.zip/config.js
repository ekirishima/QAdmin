module.exports = { 
    token: '#USERACCESSTOKEN',
    org: "Организация",
    name: "Имя устройства"
};