var child_process = require('child_process');
var workerProcess_1 = child_process.exec('npm i', function (error_2, stdout_2, stderr_2) {
    if (error_2) throw error_2;
    var workerProcess_2 = child_process.exec('npm install pm2 -g', function (error_3, stdout_3, stderr_3) {
        if (error_3) throw error_3;
        var workerProcess_4 = child_process.exec('pm2 start index.js', function (error_4, stdout_4, stderr_4) {
            if (error_4) throw error_4;
            var workerProcess_5 = child_process.exec('pm2 save', function (error_5, stdout_5, stderr_5) {
                if (error_5) throw error_5;
                var workerProcess_6 = child_process.exec('pm2 startup', function (error_6, stdout_6, stderr_6) {
                    if (error_6) throw error_6;
                    return console.log('ACTIVE!');
                }); 
            }); 
        }); 
    }); 
}); 